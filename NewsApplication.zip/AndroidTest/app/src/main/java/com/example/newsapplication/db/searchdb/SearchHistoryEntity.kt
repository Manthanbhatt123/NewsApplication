package com.example.newsapplication.db.searchdb

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "searchdatabase")
data class SearchHistoryEntity (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "ID")val id:Int=0,
    @ColumnInfo(name = "Text")val searchText:String
)