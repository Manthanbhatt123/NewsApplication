package com.example.newsapplication.db.apidb

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.newsapplication.defaultapi.DefaultArticle

@Database(entities = [DefaultArticle::class],
    version = 2,
    exportSchema = false)
abstract class RoomDb : RoomDatabase() {

    abstract fun userDao(): UserDAO?

    companion object {

        private var INSTANCE: RoomDb? = null
        fun getUserData(context: Context): RoomDb? {
            if (INSTANCE == null) {
                INSTANCE = Room.databaseBuilder(context.applicationContext, RoomDb::class.java, "Appdb")
                    .allowMainThreadQueries()
                    .build()
                Log.d("database", "getUserData: $INSTANCE")
            }

            return INSTANCE
        }
    }
}






