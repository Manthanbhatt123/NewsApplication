package com.example.newsapplication.common

import android.content.Context
import android.content.Context.CONNECTIVITY_SERVICE
import android.net.ConnectivityManager

//todo ApiKeys
//f6ae4cf58aef4a2e965cdcfa685ff261  || 317da33a77c54f499f35b432f95ba93b

object CommonValues {
    const val APIKEY ="&apiKey=317da33a77c54f499f35b432f95ba93b"
    const val BASE_URL = "https://newsapi.org/"
    const val IndNewsEndPOINT = "v2/top-headlines?country=in& $APIKEY"


 fun isNetworkAvailable(context: Context ): Boolean {
        val connectivityManager = context.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager?
        val activeNetworkInfo = connectivityManager?.activeNetworkInfo
        return activeNetworkInfo != null && activeNetworkInfo.isConnected
    }
}