package com.example.newsapplication.apiadapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.newsapplication.databinding.NewsItemrowBinding
import com.example.newsapplication.defaultapi.DefaultArticle

@SuppressLint("NotifyDataSetChanged")
class NewsAdapter(private val context: Context, private var itemlist: OnItemClick ) :
    RecyclerView.Adapter<NewsAdapter.MyviewHolder>() {

    private var userlist = mutableListOf<DefaultArticle>()

    fun dataList(
        data: ArrayList<DefaultArticle>?,
    ) {
        this.userlist = data!!.toMutableList()
        notifyDataSetChanged()
    }

    class MyviewHolder(val binding: NewsItemrowBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyviewHolder {

        return MyviewHolder(
            NewsItemrowBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MyviewHolder, position: Int) {
        val userList = userlist[position]

        Glide.with(context).load(userList.urlToImage).into(holder.binding.drImageView)
        holder.binding.tvAuthor.text = userList.author
        holder.binding.tvTitle.text = userList.title
        holder.binding.tvDescription.text = userList.description
        holder.binding.tvURL.text = userList.url
        holder.binding.tvPublished.text = userList.publishedAt
        holder.binding.tvContent.text = userList.content

        holder.itemView.setOnClickListener {
            itemlist.onClick(userList)
//            itemCheckList.newInterfaceClickListner(userList)
        }
    }

    override fun getItemCount(): Int {
        return userlist.size
    }
/*
    interface NewInterFace {
        fun newInterfaceClickListner(itemData: DefaultArticle)
    */}

    interface OnItemClick {
        fun onClick(itemData: DefaultArticle)
    }



