package com.example.newsapplication.db.apidb


import androidx.room.*
import com.example.newsapplication.defaultapi.DefaultArticle


@Dao
interface UserDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE )
    fun insertdata(arrayList: ArrayList<DefaultArticle>)

    @Query("SELECT * FROM userdata ORDER BY ID DESC")
    fun getalldata():List<DefaultArticle>

    @Query("SELECT * FROM userdata ")
    fun getOfflineData(): List<DefaultArticle>
}