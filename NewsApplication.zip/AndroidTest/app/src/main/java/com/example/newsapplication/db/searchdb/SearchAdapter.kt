package com.example.newsapplication.db.searchdb

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.newsapplication.databinding.SearchHistoryItemrowBinding

class SearchAdapter :
    RecyclerView.Adapter<SearchAdapter.Myviewholder>() {

    private var searchItems = mutableListOf<SearchHistoryEntity>()

    @SuppressLint("NotifyDataSetChanged")
    fun setsearchitem(data: List<SearchHistoryEntity>) {
        this.searchItems = data.toMutableList()
        notifyDataSetChanged()
    }

    class Myviewholder(val binding: SearchHistoryItemrowBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Myviewholder {

        return Myviewholder(
            SearchHistoryItemrowBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: Myviewholder, position: Int) {
        if (searchItems.isNotEmpty()) {
            val items: SearchHistoryEntity = searchItems.get(position)
            holder.binding.tvSearchHistorytext.text = items.searchText
        }
    }

    override fun getItemCount(): Int {

        val limit = 5

        if (searchItems.size > limit) {
            return limit
        } else {
            return searchItems.size
        }
    }


}