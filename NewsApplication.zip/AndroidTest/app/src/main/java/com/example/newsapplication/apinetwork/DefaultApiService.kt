package com.example.newsapplication.apinetwork

import com.example.newsapplication.common.CommonValues

import com.example.newsapplication.defaultapi.DefaultApi
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface DefaultApiService {
    @GET(CommonValues.IndNewsEndPOINT)
    fun getDefaultApiData(): Call<DefaultApi>

    @GET("v2/top-headlines?+ ${CommonValues.APIKEY}")
    fun getCountryWiseData(@Query("Country") country: String): Call<DefaultApi>

    @GET("v2/top-headlines?+${CommonValues.APIKEY}")
    fun searchApi(@Query("q")title: String):Call<DefaultApi>

    @GET("v2/top-headlines?+${CommonValues.APIKEY}")
    fun getCategoryWiseApi(@Query("Category")category:String):Call<DefaultApi>

    companion object {
        private var Instance: DefaultApiService? = null
        fun getInstance(): DefaultApiService {
            if (Instance == null) {
                val restrofitservice = Retrofit.Builder()
                    .baseUrl(CommonValues.BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                Instance = restrofitservice.create(DefaultApiService::class.java)
            }
            return Instance!!
        }
    }
}