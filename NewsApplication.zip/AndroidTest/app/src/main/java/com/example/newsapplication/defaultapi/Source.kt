package com.example.newsapplication.defaultapi

data class Source(
    val id: String,
    val name: String
)