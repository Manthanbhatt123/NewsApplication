package com.example.newsapplication.mainviewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.newsapplication.activity.MainActivity
import com.example.newsapplication.db.apidb.RoomDb
import com.example.newsapplication.defaultapi.DefaultApi
import com.example.newsapplication.defaultapi.DefaultArticle
import com.example.newsapplication.repository.MainRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(private val repository: MainRepository) : ViewModel() {

    val defaultUser = MutableLiveData<ArrayList<DefaultArticle>>()


    fun getDefaultUser() {
        val response = repository.getDefaultUser()
        response.enqueue(object : Callback<DefaultApi?> {

            override fun onResponse(call: Call<DefaultApi?>, response: Response<DefaultApi?>) {
                defaultUser.postValue(response.body()?.articles as ArrayList<DefaultArticle>?)
                Log.d("SuccessABCD", "onResponse: " + response.code())
            }

            override fun onFailure(call: Call<DefaultApi?>, t: Throwable) {
                Log.d("Failure", "onFailure: " + t.message)
            }
        })
    }


    fun getSearchedData(q: String) {
        val response = repository.searchApi(q)
        response.enqueue(object : Callback<DefaultApi?> {
            override fun onResponse(call: Call<DefaultApi?>, response: Response<DefaultApi?>) {
                defaultUser.postValue(response.body()?.articles as ArrayList<DefaultArticle>?)
                Log.d("SuccessABCD", "onResponse: " + response.code())
            }

            override fun onFailure(call: Call<DefaultApi?>, t: Throwable) {
                Log.d("Failure", "onFailure: " + t.message)
            }
        })
    }


    fun getCountryWiseApi(country: String) {

        val response = repository.getCountryWiseApi(country)

        response.enqueue(object : Callback<DefaultApi?> {

            override fun onResponse(call: Call<DefaultApi?>, response: Response<DefaultApi?>) {
                defaultUser.postValue(response.body()?.articles as ArrayList<DefaultArticle>)
                Log.d("Particular api", "onResponse:${response.code()} ")
            }

            override fun onFailure(call: Call<DefaultApi?>, t: Throwable) {
                Log.d("TAG", "onFailure: ${t.message}")
            }

        })

    }

    fun getCategoryWiseApi(category: String) {
        val response = repository.getCategoryWiseApi(category)
        response.enqueue(object : Callback<DefaultApi?> {
            override fun onResponse(call: Call<DefaultApi?>, response: Response<DefaultApi?>) {
                defaultUser.postValue(response.body()?.articles as ArrayList<DefaultArticle>)
            }

            override fun onFailure(call: Call<DefaultApi?>, t: Throwable) {
                TODO("Not yet implemented")
            }
        })
    }

    fun getOfflineData(mainActivity: MainActivity): List<DefaultArticle>? {
        val userDao = RoomDb.getUserData(mainActivity)?.userDao()
        return userDao?.getOfflineData()
    }

    fun insertData(arrayList: ArrayList<DefaultArticle>, app: Application) {
        val userDao = RoomDb.getUserData(app)?.userDao()
        userDao?.insertdata(arrayList)
        getUserData(app)
    }

    private fun getUserData(app: Application): List<DefaultArticle>? {
        val userDao = RoomDb.getUserData(app)?.userDao()
        return userDao?.getalldata()
    }
}