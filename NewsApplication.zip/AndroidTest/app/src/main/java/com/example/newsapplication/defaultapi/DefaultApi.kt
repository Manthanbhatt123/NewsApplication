package com.example.newsapplication.defaultapi

data class DefaultApi(
    val articles: List<DefaultArticle>,
    val status: String,
    val totalResults: Int
)