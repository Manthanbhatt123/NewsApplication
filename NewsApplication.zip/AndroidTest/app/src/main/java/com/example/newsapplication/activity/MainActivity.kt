package com.example.newsapplication.activity

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.newsapplication.activity.DisplayActivity.NewsDisplayActivity
import com.example.newsapplication.apiadapters.*
import com.example.newsapplication.apinetwork.DefaultApiService
import com.example.newsapplication.common.CommonValues
import com.example.newsapplication.databinding.ActivityMainBinding
import com.example.newsapplication.db.searchdb.SearchAdapter
import com.example.newsapplication.db.searchdb.SearchViewModel
import com.example.newsapplication.db.searchdb.SearchHistoryEntity
import com.example.newsapplication.defaultapi.DefaultArticle
import com.example.newsapplication.mainviewmodel.MainViewModel
import com.example.newsapplication.mainviewmodel.ViewModelFactory
import com.example.newsapplication.repository.MainRepository
import com.google.android.material.snackbar.Snackbar

@SuppressLint("NotifyDataSetChanged")
class MainActivity : AppCompatActivity(), NewsAdapter.OnItemClick {
    private lateinit var mBinding: ActivityMainBinding
    private lateinit var newsAdapter: NewsAdapter
    private lateinit var viewModel: MainViewModel
    private lateinit var searchAdapter: SearchAdapter
    private lateinit var searchViewModel: SearchViewModel



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        init()

    }


    private fun init() {
        initApi()
        onClickListner()
        searchApiData()
        initSearchAdapter()
        initSearchViewModel()
        callApi()
        if (CommonValues.isNetworkAvailable(this)) {
            viewModel.getDefaultUser()
        } else {
            displaySnackBar()
            val aBcd = viewModel.getOfflineData(this)
            if (aBcd != null) {
                newsAdapter.dataList(aBcd as ArrayList<DefaultArticle>)
            }
        }
    }


    private fun displaySnackBar() {

        val snackBar: Snackbar? = null

        Snackbar.make(mBinding.constraintLayout,"Fetching Data From Device",Snackbar.LENGTH_INDEFINITE).setAction("OK")
        {
                snackBar?.dismiss()
            }.show()
    }


    private fun initSearchAdapter(){
        mBinding.rvSearchHistory.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            searchAdapter = SearchAdapter()
            adapter = searchAdapter
        }
    }
    private fun initSearchViewModel(){
        searchViewModel = ViewModelProvider(this).get(SearchViewModel::class.java)
        searchViewModel.getDataObserver().observe(this){
            searchAdapter.setsearchitem(it)
            searchAdapter.notifyDataSetChanged()
        }
    }

    private fun callApi(){
        searchViewModel.getDataObserver().observe(this){
            searchAdapter.setsearchitem(it)
            searchAdapter.notifyDataSetChanged()
        }
    }

    private fun initApi() {
        val retrofitService = DefaultApiService.getInstance()

        newsAdapter = NewsAdapter(this, this)
        mBinding.recyclerView.adapter = newsAdapter
        mBinding.recyclerView.layoutManager = LinearLayoutManager(this)
        mBinding.recyclerView.addItemDecoration(DividerItemDecoration(this,LinearLayoutManager.HORIZONTAL))

        viewModel = ViewModelProvider(this, ViewModelFactory(MainRepository(retrofitService)))
            .get(MainViewModel::class.java)
        viewModel.getDefaultUser()
        viewModel.defaultUser.observe(this) {

            if (it!!.isEmpty()) {
                mBinding.tvNoDataFound.visibility = View.VISIBLE
                mBinding.recyclerView.visibility = View.GONE
            } else {
                mBinding.tvNoDataFound.visibility = View.GONE
                mBinding.recyclerView.visibility = View.VISIBLE
                newsAdapter.dataList(it)
                viewModel.insertData(it, application)
                newsAdapter.notifyDataSetChanged()
            }
        }
    }

//    @SuppressLint("UseCompatLoadingForDrawables")
    private fun onClickListner() {

        //USA
        mBinding.tvUSA.setOnClickListener {
            viewModel.getCountryWiseApi(country = "us")
        }

        //China
        mBinding.tvChina.setOnClickListener {
            viewModel.getCountryWiseApi(country = "cn")
        }

        //Russia
        mBinding.tvRussia.setOnClickListener {
            viewModel.getCountryWiseApi(country = "ru")
        }

        //Science
        mBinding.tvScience.setOnClickListener {
           viewModel.getCategoryWiseApi(category = "science")
        }

        //Techno
        mBinding.tvTechnology.setOnClickListener {

            viewModel.getCategoryWiseApi(category = "technology")
        }
    }

    private fun searchApiData() {
        mBinding.btnsearch.setOnClickListener {
            if (mBinding.etSearchView.text!!.isEmpty()) {
                viewModel.getDefaultUser()

            } else {
                mBinding.recyclerView.visibility = View.VISIBLE
                mBinding.tvNoDataFound.visibility = View.GONE
                val q = mBinding.etSearchView.text.toString()
                Log.e("TAG", "searchApiData: $q")
                viewModel.getSearchedData(q)
                val entity = SearchHistoryEntity(0,q)
                searchViewModel.getInsertData(entity)
            }
        }
    }

    override fun onClick(itemData: DefaultArticle) {
        val i = Intent(this, NewsDisplayActivity::class.java)
        i.putExtra("Image", itemData.urlToImage)
        i.putExtra("Description", itemData.description)
        i.putExtra("URL", itemData.url)
        i.putExtra("PublishedAt", itemData.publishedAt)
        i.putExtra("Content", itemData.content)
        startActivity(i)
    }


//    override fun newInterfaceClickListner(itemData: DefaultArticle) {
//        Toast.makeText(this, "New Interface Created", Toast.LENGTH_SHORT).show()
//    }
}
