package com.example.newsapplication.repository

import com.example.newsapplication.apinetwork.DefaultApiService


class MainRepository(private val DefaultApiService: DefaultApiService) {
    fun getDefaultUser() = DefaultApiService.getDefaultApiData()
    fun searchApi(q:String)=DefaultApiService.searchApi(q)
    fun getCountryWiseApi(country:String)=DefaultApiService.getCountryWiseData(country)
    fun getCategoryWiseApi(category:String) =DefaultApiService.getCategoryWiseApi(category)
}