package com.example.newsapplication.db.searchdb

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData

class SearchViewModel(app:Application):AndroidViewModel(app) {

    private val searchList = MutableLiveData<List<SearchHistoryEntity>>()

    init {
        getAllData()
    }

    fun getDataObserver():MutableLiveData<List<SearchHistoryEntity>>{
        return searchList
    }

    private fun getAllData() {
        val searchDao = SearchRoomDb.getSearchDb(getApplication())?.searchDao()
        val list =searchDao?.getSearchedHistory()
        searchList.postValue(list)
    }

    fun getInsertData(entity:SearchHistoryEntity)
    {
        val searchDao = SearchRoomDb.getSearchDb(getApplication())?.searchDao()
        searchDao?. insertSearchedHistory(entity)
        getAllData()
    }
}