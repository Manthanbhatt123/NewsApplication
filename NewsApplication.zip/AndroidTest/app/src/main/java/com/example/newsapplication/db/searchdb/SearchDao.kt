package com.example.newsapplication.db.searchdb

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SearchDao {

        @Query("SELECT * FROM searchdatabase ORDER BY id DESC LIMIT 5")
        fun getSearchedHistory(): List<SearchHistoryEntity>

        @Insert(onConflict = OnConflictStrategy.REPLACE)
        fun insertSearchedHistory(searchHistoryEntity: SearchHistoryEntity)
}