package com.example.newsapplication.activity.DisplayActivity


import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.newsapplication.databinding.ActivityDisplayBinding
import java.text.SimpleDateFormat
import java.util.*

@SuppressLint("SimpleDateFormat")
class NewsDisplayActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDisplayBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDisplayBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {
        getstring()
        btnBackIntent()
        setDateTimeZone()
    }

    private fun getstring() {
        val image = intent.getStringExtra("Image")
        val description = intent.getStringExtra("Description")
        val url = intent.getStringExtra("URL")
        val published = intent.getStringExtra("PublishedAt")
        val content = intent.getStringExtra("Content")

        Glide.with(this).load(image).into(binding.ivDisplay)
        binding.tvDescription.text = description
        binding.tvURL.text = url
        binding.tvPublished.text = published
        binding.tvContent.text = content
    }


    private fun setDateTimeZone(){
        val cal = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss aaa z")
        val dateTime = dateFormat.format(cal.time).toString()
        binding.tvPublished.text = dateTime
    }

    private fun btnBackIntent() {
        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}