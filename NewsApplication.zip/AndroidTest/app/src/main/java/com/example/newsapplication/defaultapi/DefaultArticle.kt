package com.example.newsapplication.defaultapi

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "userdata",indices = [Index(value = ["Title"], unique = true)])
data class DefaultArticle(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "ID")val id:Int,
    @ColumnInfo(name = "Author")val author: String?,
    @ColumnInfo(name = "Content")val content: String?,
    @ColumnInfo(name = "Description")val description: String?,
    @ColumnInfo(name = "Published")val publishedAt: String?,
//    @ColumnInfo(name = "Source")val source: Source,
    @ColumnInfo(name = "Title")val title: String?,
    @ColumnInfo(name = "url")val url: String?,
    @ColumnInfo(name = "Imageurl")val urlToImage: String?
)
